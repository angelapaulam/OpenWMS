/// <reference types="cypress" />

describe('OpenGTM Segurança', () => {
  beforeEach(() => {
    cy.loginGTM()
  })

  it('Perfil', () => {
    cy.visitUrl('profile/create?format=')

    // Clicando no botão "Novo F9"
    cy.get('#newTabular').click()

    // Descrição
    cy.get('#line_13 > :nth-child(8)').type('TOTEM')

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')

    // Apagando registro
    cy.get('#line_13 > .delete-column').realHover('mouse').click()
    cy.get('#line_13 > .delete-column').realHover('mouse').click()
  });

  it('Permissões', () => {
    cy.visitUrl('profilePermission/create?format=')

    // Selecionando o perfil
    cy.get('#profile\\.id').select('Carregamento - TCM', { force: true })

    // Selecionando opções em Operacional
    cy.get('#menu_3_assoc_28_submenu_nivel3_48_')
      .not('[disabled]')
      .check()
      .should('be.checked')

    cy.get('#menu_3_assoc_28_submenu_nivel3_49_')
      .not('[disabled]')
      .check()
      .should('be.checked')

    // Salvando
    cy.get('#actionSave').click()
  });

  it('Usuário', () => {
    cy.visitUrl('user/create/actionCreate')

    // Selecionando a empresa
    cy.get('#enterprise').select('SCOF', { force: true })

    // Selecionando o terminal
    cy.get('#warehouse').select('SCOF  - SCOF', { force: true })

    // Nome
    cy.get('#name').type('Fernando Peixoto QA')

    // Login/email
    cy.get('#login').type('fernando.peixoto@kmm.com.br')

    // Senha
    cy.get('#tempPassword').type('Senha#1234')

    // Repetir senha
    cy.get('#repeteNewPassword').type('Senha#1234')

    // Selecionando perfil
    cy.get('#profile').select('OpenGTP - Perfil Padrão Portal', { force: true })

    // Salvando
    cy.get('#actionSave').click()

    // Excluindo
    cy.get('#actionDelete').click()
  });
});
