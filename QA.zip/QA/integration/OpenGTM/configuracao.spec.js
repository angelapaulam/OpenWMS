/// <reference types="cypress" />

// Antes de executar este Test-suite faça as seguintes alterações:
// No test-case "Rota" altere os campos "Código da rota" e
// o "Descrição da rota".

Cypress.on('uncaught:exception', (err, runnable) => {
  return false
})
describe('OpenGTM Configuração', () => {
  beforeEach(() => {
    cy.loginGTM()
  })

  it('Cadastro terminal', () => {
    // Clicando no menu: Configuração > Terminal
    cy.visitUrl('warehouse/list?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    // Empresa
    cy.get('#enterprise').select('SCOF', { force: true })

    // Tigrama
    cy.get('#code3').type('BRA')

    // Código
    cy.get('#code').type('CODE_09')

    // Descrição
    cy.get('#description').type('Terminal de carga Santos')

    // País
    cy.get('#country').select('Brasil', { force: true })

    // Endereço
    cy.get(':nth-child(1) > #address')
      .type('Av. Conselheiro Rodrigues Alves')

    // Número
    cy.get('#addressNumber').type('S/N')

    // Bairro
    cy.get('#neighborhood').type('Macuco')

    // Cidade
    cy.get('#city').type('Santos')

    // Estado
    cy.get('#province').type('São Paulo')

    // CEP
    cy.get('#zipcode').type('11015-900')

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro salvo com sucesso.')

    // Apagando registro
    cy.get('#actionDelete').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro excluído com sucesso.')
  });

  it('Cadastro tipo de pilhas', () => {
    cy.visitUrl('addressType/create?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    cy.wait(1000)

    // Código
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .prev()
      .prev()
      .prev()
      .prev()
      .prev()
      .children()
      .type('EXG')

    // Descrição
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .prev()
      .prev()
      .prev()
      .prev()
      .children()
      .type('PILHA EXTRA GRANDE')

    // Altura
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .prev()
      .prev()
      .prev()
      .children()
      .type('10,00')

    // Largura
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .prev()
      .prev()
      .children()
      .type('40,00')

    // Comprimento
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .prev()
      .children()
      .type('20,00')

    // Peso máximo
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .children()
      .type('40.000,00')

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')

    // Apagando
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .prev()
      .prev()
      .prev()
      .prev()
      .prev()
      .prev()
      .children()
      .children()
      .dblclick()

    cy.wait(1000)

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')
  });

  it('Configuração Pilhas', () => {
    cy.visitUrl('address/create?format=')

    // Selecionando terminal
    cy.get('#warehouse').select('SCOF', { force: true })

    // Área
    cy.get('#warehouseArea').select('PATIO')
    cy.get('#warehouseArea').should('have.value', '3')

    // Quantidade
    cy.get('#amountSublevel').clear()
    cy.get('#amountSublevel').type('4')

    // Cor rua*
    cy.get('#color_AREA_BOX_0').clear()
    cy.get('#color_AREA_BOX_0').type('YELLOW')

    // Cor rua -1
    cy.get('#alias_AREA_BOX_0_RUA_0').clear()
    cy.get('#alias_AREA_BOX_0_RUA_0').type('BLUE')

    // Salva
    cy.get('#actionUpdate').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro alterado com sucesso.')

    // Validação

    cy.visitUrl('address/create?format=')

    // Selecionando terminal
    cy.get('.filter-option').click()
    cy.get('[data-original-index="1"] > a > .text').realHover('mouse')
      .click({ force: true })

    // Área
    cy.get('#warehouseArea').select('PATIO')
    cy.get('#warehouseArea').should('have.value', '3')

    // Quantidade
    cy.get('#amountSublevel').should('have.value', '4')

    // Cor rua*
    cy.get('#color_AREA_BOX_0').should('have.value', 'YELLOW')

    // Cor rua -1
    cy.get('#alias_AREA_BOX_0_RUA_0').should('have.value', 'BLUE')
  });

  it('Motivo de bloqueio de pilhas', () => {
    cy.visitUrl('addressLockCause/create?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    cy.wait(1000)

    // Código
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .children()
      .type('QA1')

    // // Digitar código
    // cy.get('#line_2 > :nth-child(6)').type('2')

    // Digitar descrição do bloqueio
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .children()
      .type('QA Armazém fechado')

    // Salvar
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')

    // Apagando
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .prev()
      .children()
      .children()
      .dblclick()

    cy.wait(1000)

    // Salvar
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')
  });

  it('Bloqueio de pilhas', () => {
    cy.visitUrl('addressLock/list?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    // Endereço
    cy.get('#addressCode').type('Rua-1')

    // Motivo do bloqueio
    cy.get('#cause').select('Armazém em inventário', { force: true })

    // Observação
    cy.get('#observation').type('Armazém em inventário')

    // Salvar
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro salvo com sucesso.')
  });

  it('Rota', () => {
    cy.visitUrl('route/list?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    // Digitando código da rota
    cy.get('#code').type('00244')

    // Digitanto a descrição da rota
    cy.get('#description').type('Rota para Doca 00244')

    // Cor da rota
    cy.get('#color').type('YELLOW')

    // Cor secundária da rota
    cy.get('#secondColor').type('BLUE')

    // Selecionando equipamento
    cy.get('#equipments').select('Totem - Balança Tara 04', { force: true })

    // Selecionando a rota pai
    cy.get('.filter-option').click()
    cy.get('[data-original-index="3"] > a > .text')
      .realHover('mouse')
      .click()
    cy.get('.filter-option').click()

    // Salvar
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro salvo com sucesso.')
  });

  it('Preferências de agendamento', () => {
    cy.visitUrl('schedulingPreferences/list?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    // Pesquisa produto
    cy.get(':nth-child(1) > .input-group > .input-group-btn > [href="#"]')
      .click({ force: true })

    // Selecionando o produto
    cy.contains('FERRO GUSA').click()

    // Característica
    cy.get('#feature').select('CONCENTRADO', { force: true })

    // Pesquisa proprietário
    cy.get(':nth-child(3) > :nth-child(3) > .input-group > .input-group-btn\
            > [href="#"]').click({ force: true })

    cy.contains('CSR SIDERURGIA LTDA').click()

    // Lote
    cy.get('#productLotId').select('11345 - HERCULANO MINERAÇÃO LTDA')

    // Pesquisa Transportadora
    cy.get(':nth-child(2) > .input-group > .input-group-btn > [href="#"]')
      .click()

    // Selecionando transportadora
    cy.contains('AJ TRANSPORTES').click()

    // Pesquisando destinatário
    cy.get(':nth-child(4) > :nth-child(3) > .input-group > .input-group-btn\
            > [href="#"]').click()

    // Selecionando destinatário
    cy.contains('Terminal SCOF').click()

    // Hora mínima aceitável
    cy.get('#minStartHour').type('4')

    // Hora máxima aceitável
    cy.get('#maxEndHour').type('22')

    // Janela de agendamento
    cy.get('#eventDuration').type('2')

    // Hora início do agendamento
    cy.get('#startHour').type('8')

    // Número máximo de agendamento por janela
    cy.get('#maxSchedulingWindow').type('30')

    // Peso mínimo aceitável
    cy.get('#minWeight').clear().type('2000')

    // Peso máximo aceitável
    cy.get('#maxWeight').type('99999')

    // Tipo de validação de peso excedido conforme programação
    cy.get('[value="S"]').not('[disabled]').check().should('be.checked')

    // Quantidade do mesmo caminhão por janela
    cy.get('#schedulingWindowAmountTruck').type('2')

    // Selecionar os dias de funcionamento
    cy.get('#sunday').not('[disabled]').check().should('be.checked')
    cy.get('#monday').not('[disabled]').check().should('be.checked')
    cy.get('#tuesday').not('[disabled]').check().should('be.checked')
    cy.get('#wednesday').not('[disabled]').check().should('be.checked')
    cy.get('#thursday').not('[disabled]').check().should('be.checked')
    cy.get('#friday').not('[disabled]').check().should('be.checked')
    cy.get('#saturday').not('[disabled]').check().should('be.checked')

    // Agendamento sem estoque
    cy.get('#allowSchedulingWithoutStock')
      .not('[disabled]')
      .check()
      .should('be.checked')

    // Valida formato da placa do caminhão
    cy.get('#plateFormatValidation')
      .not('[disabled]')
      .check()
      .should('be.checked')

    // Não permitir entrada de motorista inativo
    cy.get('#disallowInactiveDriver')
      .not('[disabled]')
      .check()
      .should('be.checked')

    // Salvando
    cy.get('.page-header')
      .contains('Salvar')
      .realHover('mouse')
      .click()

    cy.get('#actionDelete').click()
  });

  it('Produtos > Característica', () => {
    cy.visitUrl('feature/create?format=')

    // Clicar em "Novo - F9"
    cy.get('#newTabular').click()

    cy.wait(1000)

    // Código característica
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .prev()
      .prev()
      .children()
      .type('SL')

    // Descrição
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .prev()
      .children()
      .type('Sílica')

    // Texto complementar
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .children()
      .type('Sílica')

    // Cor
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .children()
      .type('RED')

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')

    // Apagando
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .prev()
      .prev()
      .prev()
      .children()
      .children()
      .dblclick()

    cy.wait(1000)

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')
  });

  it('Produtos > Natureza de carga', () => {
    cy.visitUrl('nature/create?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    cy.wait(1000)

    // Código
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .children()
      .type('Q')

    // Descrição
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .children()
      .type('QA Descrição')

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')

    // Apagando registro
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .prev()
      .children()
      .children()
      .dblclick()

    cy.wait(1000)

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')
  });

  it('Produto > Unidade de Medida', () => {
    cy.visitUrl('unitMeasure/create?format=')

    // Clicar em "Novo - F9"
    cy.get('#newTabular').click()

    cy.wait(1000)

    // Código
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .children()
      .type('QA1')

    // Descrição
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .children()
      .type('QA Medida')

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')

    // Apagando registro
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .prev()
      .children()
      .children()
      .dblclick()

    cy.wait(1000)

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')
  });

  it('Equipamentos > Tipos de Equipamentos', () => {
    cy.visitUrl('equipmentType/create?format=')

    // Clicar em "Novo - F9"
    cy.get('#newTabular').click()

    cy.wait(1000)

    // Código
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .children()
      .type('QA1')

    // Descrição
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .children()
      .type('QA Descrição')

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')

    // Apagando registro
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .prev()
      .children()
      .children()
      .dblclick()

    cy.wait(1000)

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')
  });

  it('Equipamentos > Equipamento', () => {
    cy.visitUrl('equipment/list?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    // Tipo de equipamento
    cy.get('#type').select('Camera OCR', { force: true })

    // Código
    cy.get('#code').type('01')

    // Descrição
    cy.get('#description').type('Vigilância portaria')

    // Observação
    cy.get('#observation').type('Câmera de vigilância da portaria 01')

    // Salvar
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro salvo com sucesso.')

    cy.get('#actionDelete').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro excluído com sucesso.')
  });

  it('Serviços > Motivo Manutenção', () => {
    cy.visitUrl('maintenanceCause/create?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    cy.wait(1000)

    // Código
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .children()
      .type('QA1')

    // Descrição
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .children()
      .type('QA Descrição')

    // Salvando
    cy.get('#actionSave').dblclick()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')

    // Apagando registro
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .prev()
      .children()
      .children()
      .dblclick()

    cy.wait(1000)

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')
  });

  it('Serviços > Paralizações', () => {
    cy.visitUrl('stop/create?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    cy.wait(1000)

    // Código
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .children()
      .type('QA1')

    // Descrição
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .children()
      .type('QA Descrição')

    // Salvando
    cy.get('#actionSave').dblclick()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')

    // Apagando registro
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .prev()
      .children()
      .children()
      .dblclick()

    cy.wait(1000)

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')
  });

  it('Serviços > Definição de tarefa', () => {
    cy.visitUrl('taskDefinition/list?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    // Descrição da tarefa
    cy.get('#description').type('Manutenção')

    // Tempo em horas da tarefa
    cy.get('#runtime').type('2')

    // Selecionando equipamentos
    cy.get('#equipments').select('Totem - Balança Tara 04')

    // Salvando
    cy.get('.page-header').contains('Salvar').realHover('mouse').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro salvo com sucesso.')

    cy.get('#actionDelete').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro excluído com sucesso.')
  });

  it('Modulo Resíduo > Classe do resíduo', () => {
    cy.visitUrl('residueType/create?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    cy.wait(1000)

    // Código
    cy.get("#lines\\.1\\.description")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .children()
      .type('QA1')

    // Salvando
    cy.get('#actionSave').dblclick()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')

    // Apagando registro
    cy.get("#lines\\.1\\.description")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .children()
      .children()
      .dblclick()

    cy.wait(1000)

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')
  });

  it('Modulo Resíduo > Lote do resíduo', () => {
    cy.visitUrl('residueLot/create?format=')

    // Descrição
    cy.get('#line_0 > :nth-child(6)').type('Lote 01')

    // Classe do resíduo
    cy.get('#line_0 > :nth-child(7)').select('Classe 01', { force: true })

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')

    // Apagando registro
    cy.get('#line_1 > .delete-column').click()
    cy.get('#line_1 > .delete-column').click()
  });

  it('Modulo Resíduo > Estado físico', () => {
    cy.visitUrl('residueState/create?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    // Descrição
    cy.get('#line_2 > .value').type('Sólido')

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')

    // Apagando registro
    cy.get('#line_2 > .delete-column').click()
    cy.get('#line_2 > .delete-column').click()
    cy.get('#actionSave').click()
  });

  it('Modulo Resíduo > Tipo de acondicionamento', () => {
    cy.visitUrl('residuePackagingType/create?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    // Descrição
    cy.get('#line_2 > .value').type('Container')

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')

    // Apagando registro
    cy.get('#line_2 > .delete-column').click()
    cy.get('#line_2 > .delete-column').click()
  });

  it('Modulo Resíduo > Tratamento/disposição', () => {
    cy.visitUrl('residueHandling/create?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    // Descrição
    cy.get('#line_2 > .value').type('Aterro sanitário')

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')

    // Apagando registro
    cy.get('#line_2 > .delete-column').click()
    cy.get('#line_2 > .delete-column').click()
  });

  it('Modulo Resíduo > Centro de custo', () => {
    cy.visitUrl('residueCostCenter/create?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    // Descrição
    cy.get('#line_2 > .value').type('Centro de custo Gridnet')

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')

    // Apagando registro
    cy.get('#line_2 > .delete-column').click()
    cy.get('#line_2 > .delete-column').click()
  });

  it('Modulo Resíduo > Origem do resíduo', () => {
    cy.visitUrl('residueOrigin/create?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    // Descrição
    cy.get('#line_2 > .value').type('Refugo')

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')

    // Apagando registro
    cy.get('#line_2 > .delete-column').click()
    cy.get('#line_2 > .delete-column').click()
  });

  it('Cadastro País', () => {
    cy.visitUrl('country/create?format=')

    cy.get('#newTabular').click()

    cy.wait(1000)

    // Código
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .prev()
      .prev()
      .children()
      .type('AR')

    // Trigrama
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .prev()
      .children()
      .type('ARG')

    // Descrição
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .children()
      .type('Argentina')

    // Moeda
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .children()
      .select('Peso', { force: true })

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')

    // Apagando
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .prev()
      .prev()
      .prev()
      .children()
      .children()
      .dblclick()

    cy.wait(1000)

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')
  });

  it('Cadastro Moeda', () => {
    cy.visitUrl('currency/create')

    cy.get('#newTabular').click()

    cy.wait(1000)

    // Código
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .prev()
      .children()
      .type('QA')

    // Descrição
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .children()
      .type('Iene')

    // Valor
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .children()
      .clear()
      .type('0,0532')

    // Salvando
    cy.get('#actionSave').click()

    // Apagando
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .prev()
      .prev()
      .children()
      .children()
      .dblclick()

    cy.wait(1000)

    // Salvando
    cy.get('#actionSave').click()
  });

  it('Política de pesagem', () => {
    cy.visitUrl('policyDirection/create?format=')

    cy.get('#newTabular').click()

    cy.wait(1000)

    // Tipo
    cy.get("#lines\\.1\\.startTime")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .children()
      .last()
      .prev()
      .prev()
      .prev()
      .prev()
      .prev()
      .children()
      .select('Caminhão', { force: true })

    // Placa
    cy.get("#lines\\.1\\.startTime")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .children()
      .last()
      .prev()
      .prev()
      .prev()
      .prev()
      .children()
      .children()
      .children()
      .children()
      .last()
      .children()
      .first()
      .type('AAA-3E44')

    // Frequência
    cy.get("#lines\\.1\\.startTime")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .children()
      .last()
      .prev()
      .prev()
      .prev()
      .prev()
      .children()
      .children()
      .children()
      .children()
      .last()
      .children()
      .last()
      .children()
      .select('Segunda-feira', { force: true })

    // Início
    cy.get("#lines\\.1\\.startTime")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .children()
      .last()
      .prev()
      .prev()
      .prev()
      .children()
      .type('130000')

    // Término
    cy.get("#lines\\.1\\.startTime")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .children()
      .last()
      .prev()
      .prev()
      .children()
      .type('200000')

    // Intervalo
    cy.get("#lines\\.1\\.startTime")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .children()
      .last()
      .prev()
      .children()
      .type('010000')

    // Rota
    cy.get("#lines\\.1\\.startTime")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .children()
      .last()
      .children()
      .select('GREEN METALS', { force: true })

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')

    // Apagando
    cy.get("#lines\\.1\\.startTime")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .children()
      .last()
      .prev()
      .prev()
      .prev()
      .prev()
      .prev()
      .prev()
      .children()
      .children()
      .dblclick()

    cy.wait(1000)

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')
  });

  it('Fator de conversão', () => {
    cy.visitUrl('conversionFactor/index')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    // Código
    cy.get('#code').type('01')

    // Unidade de medida de origem
    cy.get('#unitMeasureOrigin').select('2 - Quilograma', { force: true })

    // Unidade de medida de destino
    cy.get('#unitMeasureDestination').select('1 - Tonelada', { force: true })

    // Fator de conversão
    cy.get('#conversionFactor').type('1000')

    // Produto
    cy.get('#product').select('0005 - FERRO GUSA', { force: true })

    // Salvando o registro
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro salvo com sucesso.')

    // Excluindo o registro
    cy.get('#actionDelete').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro excluído com sucesso.')
  });

  it('Justificativas', () => {
    cy.visitUrl('justification/create?format=')

    cy.get('#newTabular').click()

    cy.wait(1000)

    // Descrição
    cy.get("#lines\\.1\\.description")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .children()
      .type('Saída')

    // Tipo
    cy.get("#lines\\.1\\.description")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .children()
      .type('Balança')

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')

    // Apagando o registro
    cy.get("#lines\\.1\\.description")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .prev()
      .children()
      .children()
      .dblclick()

    cy.wait(1000)

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')
  });

  it('Pontos de alerta', () => {
    cy.visitUrl('alertPoint/list')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    // Nome
    cy.get('#name').type('Totem de entrada')

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro salvo com sucesso.')

    cy.visitUrl('alertPoint/list')

    // Apagando registro
    cy.get('tbody > :nth-child(3) > :nth-child(1) > a').click()
    cy.get('#actionDelete').click()
  });

  it('Alertas', () => {
    cy.visitUrl('alert/list?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    cy.get('#alertOrigin').type('Balança 02')

    cy.get('#message').type("Peso acima do limite!")

    cy.get('#parameters').type('Máximo peso 50 toneladas')

    // cy.get('#userName').type('Teste automático')

    cy.get('#notificationEmail').type('tos_qa@kmm.com.br')

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro salvo com sucesso.')
  });


  it('EDI > Tipo de Evento', () => {
    cy.visitUrl('integrationEventType/list?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    // Código tipo evento
    cy.get('#code').type('ALERT_LOAD_WEIGH_HIGH')

    // Descrição
    cy.get('#description').type('ALERT_LOAD_WEIGH_HIGH')

    // Código (gatilho) para execução
    cy.get('#eventTrigger').type(`{}`, { parseSpecialCharSequences: false })

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro salvo com sucesso.')

    // Excluindo o registro
    cy.get('#actionDelete').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro excluído com sucesso.')
  });
});
