/// <reference types="cypress" />

// Antes de executar este Test-suite faça as seguintes alterações:
// No test-case: "Nota Fiscal" altere o campo "Código"
// No test-case: "Rodoviário > Portaria" altere o campo "Nota fiscal"
// e "Placa caminhão"


describe('OpenGTM Operacional', () => {
  beforeEach(() => {
    cy.loginGTM()
  })

  it('Nota Fiscal', () => {
    cy.visitUrl('document/list?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    // Selecionar tipo "Ticket"
    cy.get('#isTicket').not('[disabled]').check().should('be.checked')

    // Código
    cy.get('#code').type('PR_395534')

    // Data da Operação
    cy.get('.input-group > #operationDate').type('22/04/2022')

    // Valor
    cy.get('#value').clear().type('23000')

    // Proprietário
    cy.get('#owner').select('FENIX SIDERURGIA', { force: true })
    cy.get('#owner').should('have.value', '121')

    // Pesquisa destinatário
    cy.get(':nth-child(5) > :nth-child(3) > .input-group > .input-group-btn\
            > [href="#"]').click()

    // Seleciona destinatário
    cy.contains('Terminal SCOF').click()

    // Tipo de Operação
    cy.get('#warehouseOperationType').select('Regime Especial', { force: true })
    cy.get('#warehouseOperationType').should('have.value', 'E')

    // Abrir aba Transporte
    cy.get('#li-tab-2 > a').click()

    // Pesquisa Vagão
    cy.get('#rail > .row > .form-group > .col-sm-12 > .input-group-btn\
            > [href="#"]').click()

    // Selecionando o vagão
    cy.contains('GDS - 0230430').click()

    // Salvando
    cy.get('.page-header').contains('Salvar').realHover('mouse').click()

    // Mudando transporte e salvando
    // Abrir aba Transporte
    cy.get('#li-tab-2 > a').click()

    // Limpando dados "vagão"
    cy.get('[href="javascript:clearWagonFields();"]').click()

    // Pesquisando caminhão
    cy.get('#highway > .row > .form-group > .input-group > .input-group-btn\
            > [href="#"]').click()

    // Selecionando o caminhão
    cy.contains('QUI - 0001').click()

    // Pesquisando transportadora
    cy.get(':nth-child(3) > .form-group > .input-group > .input-group-btn\
            > [href="#"]').click()

    // Selecionando a transportadora
    cy.contains('2393').click()

    // Pesquisando motorista
    cy.get(':nth-child(4) > .form-group > .input-group > .input-group-btn\
            > [href="#"]').click()

    // Selecionando o motorista
    cy.contains('ABEL ANTONIO SILVESTRE').click()

    // Salvando
    cy.get('.page-header').contains('Salvar').realHover('mouse').click()
  });

  it('Ferroviário > Carregamento', () => {
    cy.visitUrl('railLoading/list?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    // Data
    cy.get('#date').type('22/04/2022{enter}')

    // Composição
    cy.get('#train').type('S1702')

    // Pesquisar produto
    cy.get(':nth-child(3) > .row > .form-group > .input-group\
            > .input-group-btn > [href="#"]').click()

    // Selecionar produto
    cy.contains('0005').click()

    // Selecionando o lote
    cy.get('#productLot').select('2855', { force: true })
    cy.get('#productLot').should('have.value', '115')

    // Pesquisando o proprietário
    cy.get(':nth-child(4) > .form-group > .input-group > .input-group-btn\
            > [href="#"]').click()

    // Selecionando proprietário
    cy.contains('CSR SIDERURGIA LTDA').click()

    // Abrindo informações adicionais
    cy.get('legend > .toggleCollapse > .more').click()

    // Previsão chegada
    cy.get('#eta').clear().type('22/04/2022{enter}')

    // Previsão manobra
    cy.get('#etb').type('23/04/2022{enter}')

    // Previsão de saída
    cy.get('#etd').type('26/04/2022{enter}')

    // Chegada 
    cy.get('#ata').type('23/04/2022{enter}')

    // Manobra
    cy.get('#atb').type('24/04/2022{enter}')

    // Saída
    cy.get('#ats').type('25/04/2022{enter}')

    // Salvando
    cy.get('.page-header').contains('Salvar').realHover('mouse').click()

    // Excluindo
    cy.get('#actionDelete').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro excluído com sucesso.')
  });

  it('Ferroviário > Descarregamento', () => {
    cy.visitUrl('railUnloading/list')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    // Data
    cy.get('#date').type('22/04/2022{enter}')

    // Composição
    cy.get('#train').type('S1702')

    // Pesquisar produto
    cy.get(':nth-child(3) > .row > .form-group > .input-group\
            > .input-group-btn > [href="#"]').click()

    // Selecionar produto
    cy.contains('0005').click()

    // Selecionando o lote
    cy.get('#productLot').select('2855', { force: true })
    cy.get('#productLot').should('have.value', '115')

    // Pesquisando o proprietário
    cy.get(':nth-child(4) > .form-group > .input-group > .input-group-btn\
            > [href="#"]').click()

    // Selecionando proprietário
    cy.contains('CSR SIDERURGIA LTDA').click()

    // Abrindo informações adicionais
    cy.get('legend > .toggleCollapse > .more').click()

    // Previsão chegada
    cy.get('#eta').clear().type('22/04/2022{enter}')

    // Previsão manobra
    cy.get('#etb').type('23/04/2022{enter}')

    // Previsão de saída
    cy.get('#etd').type('26/04/2022{enter}')

    // Chegada 
    cy.get('#ata').type('23/04/2022{enter}')

    // Manobra
    cy.get('#atb').type('24/04/2022{enter}')

    // Saída
    cy.get('#ats').type('25/04/2022{enter}')

    // Salvando
    cy.get('.page-header').contains('Salvar').realHover('mouse').click()

    // Excluindo
    cy.get('#actionDelete').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro excluído com sucesso.')
  });

  it('Rodoviário > Portaria', () => {
    cy.visitUrl('actGate/create?format=')

    // Nota fiscal
    cy.get('#document_Code').type('PR_395534')

    // Placa caminhão
    cy.get('#truck_serialCode2').type('AAA-5E38').realPress('Enter')
  });

  it('Rodoviário > Balança', () => {
    cy.visitUrl('actBalance/list')

    // Nota fiscal
    cy.get('#document_Code').type('PR_39553')

    // Data inicial do período de operação
    cy.get('#startDate').clear().type('01/01/2022{enter}')

    // Pesquisar
    cy.get('#actionFind').click()

    // Validar registro
    cy.contains('NTX - 0117')
  });

  it('Rodoviário > Suspensão de caminhões', () => {
    cy.visitUrl('truckSuspension/list?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    // Data inicial
    cy.get('#startDate').clear().type('29/04/2022{enter}')

    // Data final
    cy.get('#endDate').clear().type('30/04/2022{enter}')

    // Buscar caminhão
    cy.get('.input-group-btn > [href="#"]').click()

    // Selecionando o caminhão
    cy.contains('QUI - 0001').click()

    // Motivo
    cy.get('#cause').type('Motivo suspensão')

    // Salvando
    cy.get('#actionSave').realHover('mouse').click({ force: true })
    cy.get('#divMensagem')
      .should('have.text', 'Registro salvo com sucesso.')

    // Apagando o cadastro
    cy.get('#actionDelete').click({ force: true })
    cy.get('#divMensagem')
      .should('have.text', 'Registro excluído com sucesso.')
  });

  it('Rodoviário > Autorização de Pesagem Manual', () => {
    cy.visitUrl('manualWeightingAuthorization/list?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    // Selecione o tipo
    cy.get('#type').select('Horas', { force: true })

    // Quantidade
    cy.get('#amount').type('88888')

    // Permitir somente para estes usuários
    cy.get('#users').type('opengtm@gridnet.com.br;opengtm@scof.com.br')

    // Motivo
    cy.get('#cause').type('Horas autorizadas')

    // Salvando
    cy.get('#actionSave').realHover('mouse').click({ force: true })
    cy.get('#divMensagem')
      .should('have.text', 'Registro salvo com sucesso.')

    // Apagando o cadastro
    cy.get('#actionDelete').click({ force: true })
    cy.get('#divMensagem')
      .should('have.text', 'Registro excluído com sucesso.')
  });

  it('Paradas Programadas', () => {
    cy.visitUrl('scheduledStop/list?format=')

    // Clicando no botão "Novo F9"
    cy.get("#actionCreate").click()

    // Autorizado pela gerência
    cy.get('#authorized').not('[disabled]').check().should('be.checked')

    // Qual paralização
    cy.get("#stop").select('Manutenção na balança', { force: true })

    // Descrição
    cy.get('#description').type('QA Descrição da parada')

    // Data / hora início
    cy.get('#startDate').clear().type('01/12/2022{enter}')

    // Data / hora fim
    cy.get('#endDate').clear().type('02/12/2022{enter}')

    // Motivo da manutenção
    cy.get('#maintenanceCause').select('Local em reforma', { force: true })

    // Lista de equipamentos
    cy.get('#equipments').select('Totem - Balança Tara 04', { force: true })

    // Detalhes do impacto no processo
    cy.get('#processImpact').type('QA detalhe')

    // Observação
    cy.get('#observation').type('QA Observação')

    // Salvando
    cy.get('#actionSave').realHover('mouse').click({ force: true })
    cy.get('#divMensagem')
      .should('have.text', 'Registro salvo com sucesso.')

    // Apagando o cadastro
    cy.get('#actionDelete').click({ force: true })
    cy.get('#divMensagem')
      .should('have.text', 'Registro excluído com sucesso.')
  });

  it('Empresa Receptora', () => {
    cy.visitUrl('residueReceiver/list?format=')

    // Clicando no botão "Novo F9"
    cy.get("#actionCreate").click()

    // Nome
    cy.get('#name').type('QA Empresa teste')

    // Razão social
    cy.get('#description').type('QA Empresa teste')

    // CNPJ
    cy.get('#document').clear().type('30.293.671/0001-59')

    // Inscrição estadual
    cy.get('#registerState').type('204.24474-07')

    // Inscrição municipal
    cy.get('#registerMunicipal').type('204.24474-07')

    // Telefone
    cy.get('#phone').type('(042) 3032-2021')

    // Contato
    cy.get('#contact').type('Francisco')

    // Telefone de contato
    cy.get('#contactPhone').type('(042) 99988-7766')

    // email
    cy.get('#email').type('qa@kmm.com.br')

    // Endereço
    cy.get('#address').type('Rua Coronel Vivida')

    // Número
    cy.get('#addressNumber').type('123')

    // Bairro
    cy.get('#neighborhood').type('Nova Russia')

    // Cidade
    cy.get('#city').type('Ponta Grossa')

    // Estado
    cy.get('#province').select('Paraná', { force: true })

    // CEP
    cy.get('#zipcode').type('84070-000')

    // Observação
    cy.get('#observation').type('QA observação')

    // Salvando
    cy.get('#actionSave').realHover('mouse').click({ force: true })
    cy.get('#divMensagem')
      .should('have.text', 'Registro salvo com sucesso.')

    // Apagando o cadastro
    cy.get('#actionDelete').click({ force: true })
    cy.get('#divMensagem')
      .should('have.text', 'Registro excluído com sucesso.')
  });

  it('Eventos', () => {
    cy.visitUrl('event/list?format=')

    // Clicando no botão "Novo F9"
    cy.get("#actionCreate").click()

    // Alvo
    cy.get("#eventTarget").select('Navio', { force: true })

    // Tipo do evento
    cy.get('#type').select('Operacional', { force: true })

    // Grupo
    cy.get("#group").select('QA Evento teste', { force: true })

    // Tipo de Operações
    cy.get("#operationTypes").select('QA - descrição', { force: true })

    // Descrição do evento
    cy.get('#description').type('QA evento')

    // Marcação
    cy.get('#tag').type('QA marcação')

    // Ordem
    cy.get('#order').type('1')

    // Evento com Data Final?
    cy.get('#hasEndDate').not('[disabled]').check().should('be.checked')

    // Enviar alerta ? (Módulo de alerta do OpenGTP)
    cy.get('#addAlert').not('[disabled]').check().should('be.checked')

    // Criar OS automatico?
    cy.get('#createOS').not('[disabled]').check().should('be.checked')

    // Emails para Notificação
    cy.get('#warnMails').type('qa@kmm.com.br')

    // Texto para criação da OS
    cy.get('#osText').type('QA texto para criação da OS')

    // Observação
    cy.get('#observation').type('QA observação')

    // Salvando
    cy.get('#actionSave').realHover('mouse').click({ force: true })

    // Apagando o cadastro
    cy.get('#actionDelete').click({ force: true })
  });

  it('Grupo de Eventos', () => {
    cy.visitUrl('eventGroup/create?format=')

    // Clicando no botão "Novo F9"
    cy.get("#newTabular").click()

    cy.wait(1000)

    // Código
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .children()
      .type('100')

    // Descrição
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .children()
      .type('QA Evento teste 100')

    // Salvando
    cy.get('#actionSave').realHover('mouse').click({ force: true })

    // Apagando
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .prev()
      .children()
      .children()
      .dblclick()

    cy.wait(1000)

    // Salvando
    cy.get('#actionSave').realHover('mouse').click({ force: true })
  });

  it('Operações de Eventos', () => {
    cy.visitUrl('eventOperationType/create?format=')

    // Clicando no botão "Novo F9"
    cy.get("#newTabular").click()

    cy.wait(1000)

    // Código
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .prev()
      .prev()
      .children()
      .type('QA1')

    // Descrição
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .prev()
      .children()
      .type('QA descrição')

    // Tipo de processo
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .children()
      .select('Load', { force: true })

    // Salvando
    cy.get('#actionSave').realHover('mouse').click({ force: true })
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')

    // Apagando
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .prev()
      .prev()
      .prev()
      .children()
      .children()
      .dblclick()

    cy.wait(1000)

    // Salvando
    cy.get('#actionSave').realHover('mouse').click({ force: true })
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')
  });
});
