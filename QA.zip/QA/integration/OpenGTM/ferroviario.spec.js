/// <reference types="cypress" />

describe('OpenGTM Cadastro Ferroviário', () => {
  beforeEach(() => {
    cy.loginGTM()
  })

  it('Ferroviário', () => {

    // Clicando no botão "Ferroviário"
    cy.get('#frmMain > div.container-fluid > div:nth-child(6) > div.col-sm-5 >\
            div > ul > li:nth-child(2) > a > span.ico.i-ferroviario')
      .click()

    // Mostrar o primeiro registro
    cy.get('#railInside > table > tbody > tr:nth-child(2) > td:nth-child(9)\
            > a')
      .click()

    // Adicionar um novo registro
    cy.get('#frmMain > div.page-header > div > div.page-header-buttons\
            > a:nth-child(5)')
      .click()

    // Data
    cy.get('#date')
      .clear()
      .type('30/08/2022')
      .realPress('Enter')

    // Fluxo
    // cy.get("#flow")
    //   .select('FluxoTeste', { force: true })

    // Composição
    cy.get('#train')
      .type('Composição Teste')

    // Buscando produto
    cy.get('#home > div:nth-child(3) > div.row > div > div > span\
            > a:nth-child(1)')
      .click()

    // Selecionando produto
    cy.contains('FERRO GUSA')
      .click()

    // Lote
    cy.get('#productLot')
      .select('116', { force: true })

    // Buscando proprietário
    cy.get('#home > div:nth-child(4) > div > div > span > a:nth-child(1)')
      .click()

    // Selecionando proprietário
    cy.contains('CARBOFER SIDERURGICA')
      .click()

    // Salvar
    cy.get('#actionSave')
      .click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro salvo com sucesso.')
  });
});
