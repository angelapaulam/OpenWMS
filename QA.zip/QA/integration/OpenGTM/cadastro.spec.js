/// <reference types="cypress" />

// Antes de executar este Test-suite faça as seguintes alterações:
// No test-case: "Modais Caminhão" altere o campo placa
// No test-case: "Transportadora" altere os campos "Nome" e o "Documento".
// No test-case: "Internivientes" altere os campos "Documento", "Licença".
// Este registro não é possível excluir.
// No test-case: "Motorista" altere os campos "CPF"(válido) e "CNH"
// O sistema OpenGTM não exlui estes registros e novos registros valida os
// campos mencionados

Cypress.on('uncaught:exception', (err, runnable) => {
  return false
})

describe('OpenGTM Cadastros', () => {
  beforeEach(() => {
    cy.loginGTM()
  })

  it('Cadastrando um novo produto', () => {
    cy.visitUrl('product/list?format=')

    // Verificando que é página correta de produtos
    cy.url().should('include', '/product/list')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    // Digitando o nome do produto
    cy.get('#description').type('HIDROGÊNIO')

    // Selecionando a característica
    cy.get('#feature').select('CONCENTRADO', { force: true })

    // Selecionando a natureza da carga
    cy.get('#nature').select('Granel líquido', { force: true })

    // Selecionando a unidade de medida
    cy.get('#unitMeasure').select('2 - Quilograma', { force: true })

    //  Descrição do produto
    cy.get('#materialDescription').type('HIDROGÊNIO')

    // Observação
    cy.get('#observation').type('INFLAMÁVEL')

    // Salvando o novo produto
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro salvo com sucesso.')
  })

  it('Lote', () => {
    cy.visitUrl("productLot/create/actionCreate")

    // Código
    cy.get('#code').type('L001QA')

    // Descrição
    cy.get('#description').type('Lote 001QA')

    // Capacidade máxima (ton)
    cy.get('#capacity').clear().type('300000,00')

    // Data abertura
    cy.get('#openingDate').clear().type('30/06/2022')

    // Data fechamento
    cy.get('#closingDate').clear().type('30/07/2022')

    // Buscando produto
    cy.get('.form-group.col-sm-6 > .input-group > .input-group-btn > [href="#"]')
      .click()

    // Selecionando produto
    cy.contains('FERRO GUSA').click()

    // Buscando proprietário
    cy.get('.col-sm-3 > .input-group > .input-group-btn > [href="#"]')
      .click()

    // Selecionando proprietário
    cy.contains('CARBOFER SIDERURGICA').click()

    // Cor (hexadecimal)
    cy.get('#color').type('#0000FF')

    // Salvando o novo produto
    cy.get('#actionSave').click()

    // Excluindo o registro
    cy.get('#actionDelete').click({ force: true })
  })

  it('Modais > Caminhão', () => {
    cy.visitUrl('truck/list?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    // Primeiras 3 letras da placa
    cy.get('#serial').type('AAA')

    // ùltimos 4 dígitos da placa
    cy.get('#code').type('5E37')

    // Buscando transportadora
    cy.get('.input-group-btn > [href="#"]').click()

    cy.contains('AJ TRANSPORTES').click()

    cy.get('#description').type('Cadastrado na Portaria')

    // Salvando o novo proprietário
    cy.get('#actionSave').realHover('mouse').click({ force: true })
  })

  it('Vagão', () => {
    cy.visitUrl('wagon/list?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    // Primeiras 3 letras da placa
    cy.get('#serial').type('ABB')

    // ùltimos 4 dígitos da placa
    cy.get('#code').type('4E56')

    cy.get('#description').type('Cadastrado no carregamento')

    // Salvando o novo proprietário
    cy.get('#actionSave').realHover('mouse').click({ force: true })
    cy.get('#divMensagem')
      .should('have.text', 'Registro salvo com sucesso.')

    // Excluindo o registro
    cy.get('#actionDelete').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro excluído com sucesso.')
  });

  it('Lancha', () => {
    cy.visitUrl('boat/create?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    cy.wait(1000)

    // Código
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .children()
      .type('QA1')

    // Descrição
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .children()
      .type('QA1 Lancha')

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')

    // Apagando
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .prev()
      .children()
      .children()
      .dblclick()

    cy.wait(1000)

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')
  });

  it('Rebocador', () => {
    cy.visitUrl('tugboat/create?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    cy.wait(1000)

    // Código
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .children()
      .type('QA1')

    // Descrição
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .children()
      .type('QA1 Rebocador')

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')

    // Apagando
    cy.get("#lines\\.1\\.code")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .prev()
      .children()
      .children()
      .dblclick()

    cy.wait(1000)

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')
  });

  it('Modelo do veículo', () => {
    cy.visitUrl('truckAxle/create?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    cy.wait(1000)

    // Descrição
    cy.get("#lines\\.1\\.description")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .children()
      .type('QA1')

    // Peso máximo
    cy.get("#lines\\.1\\.description")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .children()
      .clear()
      .type('45000')

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')

    // Apagando
    cy.get("#lines\\.1\\.description")
      .parent()
      .siblings()
      .parent()
      .siblings()
      .last()
      .children()
      .children()
      .last()
      .parent()
      .prev()
      .prev()
      .children()
      .children()
      .dblclick()

    cy.wait(1000)

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro(s) alterado(s) com sucesso.')
  });

  it('Transportadora', () => {
    cy.visitUrl('carrier/list?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    // Pessoa física
    cy.get('#cpf').not('[disabled]').check().should('be.checked')

    // Pessoa jurídica
    cy.get('#cnpj').not('[disabled]').check().should('be.checked')

    // Nome
    cy.get('#name').type('Silvio Melo Oliveiras')

    // Razão social
    cy.get('#description').type('Silvio Transport')

    // Documento - CNPJ
    cy.get('#document').type('78.419.990/0001-94')

    // Inscrição Estadual
    cy.get('#registerState').type('226.300.820.840')

    // Telefone
    cy.get('#phone').type('(011) 3789-2365')

    // Contato
    cy.get('#contact').type('João da Silva')

    // Inscrição municipal
    cy.get('#registerMunicipal').type('745.496.154.403')

    // Telefone contato
    cy.get('#contactPhone').type('(011) 99876-3071')

    // E-mail
    cy.get('#field1').type('josesilva@ramostransportes.com.br')

    // Senha
    cy.get('#field2').type('123@456')

    // Registro da ANTT
    cy.get('#RNTRC').type('ETC-12345678')

    // Início do bloqueio
    cy.get('#blockStartDate').clear().type('20/04/2022')

    // Fim do bloqueio
    cy.get('#blockEndDate').clear().type('22/04/2022')

    // Endereço
    cy.get('#address').type('Rua das transportadoras')

    // Número/complemento
    cy.get('#addressNumber').type('1234')

    // Bairro
    cy.get('#neighborhood').type('Barro Novo')

    // Cidade
    cy.get('#city').type('Serra')

    // Estado
    cy.get('#province').select('Espírito Santo', { force: true })

    // CEP
    cy.get('#zipcode').type('29177-741')

    // Observação
    cy.get('#observation').type('Cadastro OK')

    // Salvando
    cy.get('#actionSave').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro salvo com sucesso.')
  });

  it('Origem', () => {
    cy.visitUrl('origin/list?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    // Nome
    cy.get('#name').type('Ponta Grossa')

    // Trigrama
    cy.get('#code3').type('PGZ')

    // País
    cy.get('#country').select('Brasil', { force: true })

    // Descrição
    cy.get('#description').type('Transportadora Ponta Grossa')

    // Documento
    cy.get('#document').type('73.928.142/0001-96')

    // E-mail
    cy.get('#email').type('contato@pgtranportes.com.br')

    // Telefone
    cy.get('#phone').type('(042) 3298-3356')

    // Fax
    cy.get('#fax').type('(042) 3298-3357')

    // Contato
    cy.get('#contact').type('Luiz')

    // Telefone contato
    cy.get('#contactPhone').type('(042) 98956-3355')

    // Warehouse
    cy.get('#associateWarehouse').select('SCOF', { force: true })

    // Endereço
    cy.get(':nth-child(1) > #address').type('R. Padre Anacleto')

    // Número/Complemento
    cy.get('#addressNumber').type('396')

    // Bairro
    cy.get('#neighborhood').type('Nova Rússia')

    // Cidade
    cy.get('#city').type('Ponta Grossa')

    // Estado
    cy.get('#province').type('Paraná')

    // CEP
    cy.get('#zipcode').type('84070-320')

    // Observação
    cy.get('#observation').type('Cadastro OK')

    // Salvando
    cy.get('#actionSave').realHover('mouse').click({ force: true })
    cy.get('#divMensagem')
      .should('have.text', 'Registro salvo com sucesso.')

    // Apagando o cadastro
    cy.get('#actionDelete').click({ force: true })
    cy.get('#divMensagem')
      .should('have.text', 'Registro excluído com sucesso.')
  });

  it('Destino', () => {
    cy.visitUrl('receiver/create/actionCreate')

    // Clicando no botão "Novo F9"
    cy.get('#actionCreate').click()

    // Nome
    cy.get('#name').type('Ponta Grossa')

    // Trigrama
    cy.get('#code3').type('PGZ')

    // País
    cy.get('#country').select('Brasil', { force: true })

    // Descrição
    cy.get('#description').type('Transportadora Ponta Grossa')

    // Documento
    cy.get('#document').type('73.928.142/0001-96')

    // E-mail
    cy.get('#email').type('contato@pgtranportes.com.br')

    // Telefone
    cy.get('#phone').type('(042) 3298-3356')

    // Contato
    cy.get('#contact').type('Luiz')

    // Telefone contato
    cy.get('#contactPhone').type('(042) 98956-3355')

    // Endereço
    cy.get(':nth-child(1) > #address').type('R. Padre Anacleto')

    // Número/Complemento
    cy.get('#addressNumber').type('396')

    // Bairro
    cy.get('#neighborhood').type('Nova Rússia')

    // Cidade
    cy.get('#city').type('Ponta Grossa')

    // Estado
    cy.get('#province').type('Paraná')

    // CEP
    cy.get('#zipcode').type('84070-320')

    // Observação
    cy.get('#observation').type('Cadastro OK')

    // Salvando
    cy.get('#actionSave').realHover('mouse').click({ force: true })

    // Apagando o cadastro
    cy.get('#actionDelete').click({ force: true })
    cy.get('#divMensagem')
      .should('have.text', 'Registro excluído com sucesso.')
  });

  it('Pessoas > Pessoa', () => {
    cy.visitUrl('person/list?format=')

    // Clicando no botão "Novo F9"
    cy.get('#frmMain > div.page-header > div > div.page-header-buttons > a')
      .click()

    // Nome
    cy.get('#name').type('Sérgio Melo')

    // CPF
    cy.get('#document').type('123.456.789-01')

    // Licença/Registro
    cy.get('#license').type('123.654.987')

    // E-mail
    cy.get('#email').type('sergio.melo@gmail.com')

    // Telefone
    cy.get('#phone').type('(041) 3287-3355')

    // Celular
    cy.get('#cellphone').type('(041) 99291-8978')

    // Tipo de Pessoa
    // cy.get(':nth-child(4) > .form-group > .btn-group > .btn >\
    //  .filter-option').type('') /* COM FALHA - não tem dados no combobox */

    // Endereço
    cy.get('#address').type('R. Dom Pedro II')

    // Número/Complemento
    cy.get('#addressNumber').type('1210')

    // Bairro
    cy.get('#neighborhood').type('Centro')

    // Cidade
    cy.get('#city').type('Campo Largo')

    // Estado
    cy.get('#province').select('Paraná', { force: true })

    // CEP
    cy.get('#zipcode').type('83.601-080')

    // Observação
    cy.get('#observation').type('Cadastro OK')

    // Salvando
    cy.get('#actionSave').realHover('mouse').click({ force: true })

    // Apagando o cadastro
    cy.get('#actionDelete').click({ force: true })
    cy.get('#divMensagem')
      .should('have.text', 'Registro excluído com sucesso.')
  });

  it('Motorista', () => {
    cy.visitUrl('driver/list?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    // CPF
    cy.get('#document').type('783.892.790-02')

    // CNH
    cy.get('#license').type('63523979506')

    // Nome
    cy.get('#name').type('Luiz Cândido Limas')

    // Email
    cy.get('#email').type('luiz.c@hotmail.com')

    // Buscar transportadora
    cy.get('.input-group-btn > [href="#"]').click()

    // Selecionar Transportadora
    cy.contains('AJ TRANSPORTES').click()

    // Telefone
    cy.get('#phone').type('042 32366688')

    // Celular
    cy.get('#cellphone').type('042 992792255')

    // Início do bloqueio
    cy.get('.input-group > #blockStartDate')
      .clear()
      .type('30/06/2022')

    // Fim do bloqueio
    cy.get('.input-group > #blockEndDate')
      .clear()
      .type('30/07/2022')

    // Endereço
    cy.get('#address')
      .type('Rua Simões')

    // Número/Comp
    cy.get('#addressNumber')
      .type('123')

    // Bairro
    cy.get('#neighborhood')
      .type('Butantan')

    // Cidade
    cy.get('#city')
      .type('São Francisco do Sul')

    // Estado
    cy.get('#province')
      .select('Santa Catarina', { force: true })

    // CEP
    cy.get('#zipcode')
      .type('89240-000')

    // Observação
    cy.get('#observation')
      .type('Aguardando aprovação')

    // Salvando
    cy.get('#actionSave').realHover('mouse').click({ force: true })
  });

  it('Internivientes', () => {
    cy.visitUrl('intervener/list?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    // Tipos
    cy.get('#types').select('Despachante', { force: true })

    // País
    cy.get('#country').select('Brasil', { force: true })

    // Documento
    cy.get('#document').type('884.106.990-28')

    // Licença
    cy.get('#license').type('71344241151')

    // Nome
    cy.get('#name').type('André Lima Silva')

    // E-mail
    cy.get('#email').type('andre.lima@gmail.com')

    // Telefone
    cy.get('#phone').type('(042) 3265-4655')

    // Celular
    cy.get('#cellphone').type('(042) 99852-3265')

    // Endereço
    cy.get(':nth-child(1) > #address').type('Av. Airton Senna')

    // Número/Complemento
    cy.get('#addressNumber').type('456')

    // Bairro
    cy.get('#neighborhood').type('Vila Operária')

    // Cidade
    cy.get('#city').type('Ponta Grossa')

    // Estado
    cy.get('#province').type('Paraná')

    // CEP
    cy.get('#zipcode').type('84062-160')

    // Observação
    cy.get('#observation').type('Terceiro KMM')

    // Salvando
    cy.get('#actionSave').realHover('mouse').click({ force: true })
    cy.get('#divMensagem')
      .should('have.text', 'Registro salvo com sucesso.')
  });

  it('Cadastrando um novo proprietário', () => {
    cy.visitUrl('productOwner/list?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    // Verificando que é a página de novo proprietário
    cy.url().should('include', 'productOwner/create/actionCreate')

    // Nome do proprietário
    cy.get('#name').type('KMM QA')

    // Documento
    cy.get('#document').type('73.928.142/0001-81')

    // Data do registro
    cy.get('#registerDate').clear()
    cy.get('#registerDate').type('10/02/2021')

    // Digitando a razão social
    cy.get('#description').type('KMM Logística Ltda')

    // Inscrição estadual
    cy.get('#registerState').type('745.496.154.402')

    // email
    cy.get('#email').type('contato@kmm.com.br')

    // telefone
    cy.get('#phone').type('011 303279880')

    // Contato
    cy.get('#contact').type('Rubens')

    // Telefone
    cy.get('#contactPhone').type('01145349858347')

    // Gerencia ordem de venda
    cy.get('#manageSalesOrder').click()

    // Tempo de pesagens em minutos
    cy.get('#minTimeBetweenWeighings').type('60')

    // Tempo de operação em minutos
    cy.get('#maxSchedulingTime').type('180')

    // Salvando o novo proprietário
    cy.get('#actionSave').realHover('mouse').click({ force: true })

    // Validando o cadastro do novo proprietário
    cy.visitUrl('productOwner/list?format=')

    // Proprietário cadastrado
    cy.get('#name').type('KMM QA')

    // Buscando registro
    cy.get('#actionFind').click()

    // Validando registro
    cy.get('.odd > :nth-child(2) > a').should('contain', 'KMM QA')

    // Apagando o cadastro
    cy.get('.link-ico-edit').click({ force: true })
    cy.get('#actionDelete').click({ force: true })
  })

  it('Qualidade x Produtos', () => {
    cy.visitUrl('quality/list?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    // Pesquisa de produto
    cy.get(':nth-child(1) > .input-group > .input-group-btn > [href="#"]')
      .click()

    // Seleciona produto
    cy.contains('MINÉRIO GRANULADO').click()

    // Pesquisa Proprietário
    cy.get(':nth-child(2) > .input-group > .input-group-btn > [href="#"]')
      .click()

    // Seleciona proprietário
    cy.contains('CSR SIDERURGIA LTDA').click()

    // E-mail
    cy.get('#warnMails').type('notificacao@csr.siderurgia.com.br')

    // Observação
    cy.get('#observation').type('Grau de qualidade máxima')

    // Salvando
    cy.get('#actionSave').realHover('mouse').click({ force: true })
    cy.get('#divMensagem')
      .should('have.text', 'Registro salvo com sucesso.')

    // Apagando o cadastro
    cy.get('#actionDelete').click({ force: true })
    cy.get('#divMensagem')
      .should('have.text', 'Registro excluído com sucesso.')
  });

  it('Ordem de Serviço', () => {
    cy.visitUrl('orderService')

    /*TODO Apos a página for desenvolvida*/
  });

  it('Empresa', () => {
    cy.visitUrl('company')

    /*TODO Apos a página for desenvolvida*/
  });

  it('Pacote de serviço', () => {
    cy.visitUrl('servicePack')

    /*TODO Apos a página for desenvolvida*/
  });

  it('Solicitação de serviço', () => {
    cy.visitUrl('serviceRequest')

    /*TODO Apos a página for desenvolvida*/
  });
});
