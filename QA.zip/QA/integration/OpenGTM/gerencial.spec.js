/// <reference types="cypress" />

// Antes de executar este Test-suite faça as seguintes alterações:
// No test-case: "Terminal" altere os campos "Código" e "Descrição"

describe('OpenGTM Gerencial', () => {
  beforeEach(() => {
    cy.loginGTM()
  })

  it('Faturamento', () => {
    cy.visitUrl('billing/list?format=')

    // Clicando no botão "Novo F9"
    cy.get('#frmMain > div.page-header > div > div.page-header-buttons > a')
      .click()

    // Política de Preço
    cy.get('#price')
      .select('Aço | Gerdau Sinter | GERDAU SINTER - Recebimento', { force: true })

    // Data início
    cy.get('#startDate').clear().type('30/04/2022{enter}')

    // Data fim
    cy.get('.input-group > #finishDate').clear().type('10/05/2022{enter}')

    // Lote
    cy.get('#billingLot').select('GERDAUSAFM SINTER', { force: true })

    // Salvando
    cy.get('.page-header').contains('Salvar').realHover('mouse').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro salvo com sucesso.')

    // Excluindo
    cy.get('#actionDelete').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro excluído com sucesso.')
  });

  it('Política de preço', () => {
    cy.visitUrl('stockPrice/list?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    // Proprietário
    cy.get("#owner\\.id").select('CARBOFER SIDERURGICA', { force: true })

    // Característica do produto
    cy.get('#feature').select('Ferro Gusa', { force: true })

    // Descrição
    cy.get('#description').type('Aço')

    // Prazo de vencimento
    cy.get(':nth-child(3) > .col-sm-3 > .form-control').type('360')

    // Processo
    cy.get('#movementPriceType').select('Recebimento', { force: true })

    // Valor por tonelada 1
    cy.get('#movementPriceDay1').type('150000')

    // Limite em tonelada 1
    cy.get('#movementPriceLimit1').clear().type('100')

    // Valor por tonelada 2
    cy.get('#movementPriceDay2').type('200000')

    // Limite tonelada 2
    cy.get('#movementPriceLimit2').clear().type('70')

    // Valor por tonelada 3
    cy.get('#movementPriceDay3').type('300000')

    // Valor
    cy.get('#freetimePrice').type('30000')

    // Limite de dias
    cy.get('#freetime').type('7')

    // Valor 1
    cy.get('#freetimePriceDay1').type('25000')

    // Limite de dias 1
    cy.get('#freetimePriceLimit1').type('15')

    // Valor 2
    cy.get('#freetimePriceDay2').type('15000')

    // Limite de dias 2
    cy.get('#freetimePriceLimit2').type('20')

    // Valor 3
    cy.get('#freetimePriceDay3').type('10000')

    // Salvando
    cy.get('.page-header').contains('Salvar').realHover('mouse').click()

    // Excluindo
    cy.get('#actionDelete').click()
  });

  it('Planejamento de inventário', () => {
    cy.visitUrl('inventory/list?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    // Tipo
    cy.get('#type').select('Inventário (+)', { force: true })

    // Nota fiscal
    cy.get('#documentCode').type('SC_395465')

    // Buscar nota fiscal
    cy.get('#findDocument > .glyphicon').click()

    // Local
    cy.get('#addressTo').select('RUA-1', { force: true })

    // Justificativa
    cy.get('#cause').type('Teste QA')

    // Salvando
    cy.get('.page-header')
      .contains('Salvar')
      .realHover('mouse')
      .click({ force: true })
  });

  it('Planejamento', () => {
    cy.visitUrl('planning/list?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    // Descrição
    cy.get('#description').type('Planejamento')

    // Buscar proprietário
    cy.get('#registerOwner').click()

    // Selecionar proprietário
    cy.contains('CARBOFER SIDERURGICA').click()

    // Selecionar produto
    cy.get('#feature').select('Ferro Gusa', { force: true })

    // Tipo de planejamento
    cy.get('[value="OG"]').not('[disabled]').check().should('be.checked')

    // Período - início
    cy.get('#startDate').type('10/05/2022')

    // Até
    cy.get('#endDate').type('20/05/2022')

    // Salvando
    cy.get('.page-header').contains('Salvar').realHover('mouse').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro salvo com sucesso.')

    // Excluindo
    cy.get('#actionDelete').click()
    cy.get('#divMensagem')
      .should('have.text', 'Registro excluído com sucesso.')
  });

  it('Gestão de cota', () => {
    cy.visitUrl('quotaManagement/list?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    // Descrição
    cy.get('#description').type('Planejamento rodoviário')

    // Buscando proprietário
    cy.get('.col-sm-3 > .input-group > .input-group-btn > [href="#"]').click()

    // Selecionando proprietário
    cy.contains('CARBOFER SIDERURGICA').click()

    // Buscando produto
    cy.get('.col-sm-6 > .input-group > .input-group-btn > [href="#"]').click()

    // Selecionando produto
    cy.contains('FERRO GUSA').click()

    // Data inicial
    cy.get('#startDate').clear().type('10/10/2022')

    // Data final
    cy.get('#endDate').clear().type('10/12/2022')

    // Peso máximo
    cy.get('#maxWeight').type('1000000')

    // Envio de nota fiscal automática para a impressora
    cy.get('#sendDocumentERP').not('[disabled]').check().should('be.checked')

    // Planejamento com gestão de OV
    cy.get('#manageSalesOrder').not('[disabled]').check().should('be.checked')

    // Regras de PBT
    // Peso máximo
    cy.get('#allowUpDiffWeight').type('7000000')

    // Salvando
    cy.get('.page-header').contains('Salvar').realHover('mouse').click()
  });

  it('Terminal', () => {
    cy.visitUrl('warehouse/list?format=')

    // Clicando no botão "Novo F9"
    cy.get('.page-header')
      .contains('Novo')
      .realHover('mouse')
      .click()

    // Empresa
    cy.get('#enterprise').select('SCOF', { force: true })

    // Trigrama
    cy.get('#code3').type('BRA')

    // Código
    cy.get('#code').type('01234581')

    // Descrição
    cy.get('#description').type('Terminal SCOF 01234581')

    // Pais
    cy.get('#country').select('Brasil', { force: true })

    // Endereço
    cy.get(':nth-child(1) > #address').type('Rua Ambrozio Fagundes')

    // Número
    cy.get('#addressNumber').type('1234')

    // Bairro
    cy.get('#neighborhood').type('Nova Andrina')

    // Cidade
    cy.get('#city').type('Serra Talhada')

    // Estado
    cy.get('#province').type('Pernambuco')

    // CEP
    cy.get('#zipcode').type('56903560')

    // Salvando
    cy.get('.page-header').contains('Salvar').realHover('mouse').click()

    // Excluindo
    cy.get('#actionDelete').click()
  });
});
