/// <reference types="cypress" />

Cypress.on('uncaught:exception', (err, runnable) => {
  return false
})

describe('Agendamento', () => {
  beforeEach(() => {
    cy.loginAgendamento()
  })

  it('Agendar', () => {
    // Abrir novo agendamento
    cy.get('#acoes > div.box-body > div:nth-child(1) > div > a')
      .click()

    // Selecione o proprietário
    cy.get("#selectOwner")
      .select('CARBOFER SIDERURGICA LTDA - 18906082000101', { force: true })

    // Característica
    cy.get("#selectFeature").select('GRANEL', { force: true }, { confirm: true })

    // Selecione o destinatário
    cy.get('#selectReceiver')
      .select('Terminal SCOF - 25.248.484/1841-84', { force: true })

    // Selecione o produto
    cy.get('#selectQuota')
      .select('Terminal SCOF - 25.248.484/1841-84 | Lote: 2855', { force: true })

    // Clicar em próximo dia
    cy.get("#calendar > div.fc-toolbar.fc-header-toolbar > div.fc-left > div >\
            button.fc-next-button.ui-button.ui-state-default.ui-corner-right")
      .click()
    cy.get("#calendar > div.fc-toolbar.fc-header-toolbar > div.fc-left > div >\
            button.fc-next-button.ui-button.ui-state-default.ui-corner-right")
      .click()
    cy.get("#calendar > div.fc-toolbar.fc-header-toolbar > div.fc-left > div >\
            button.fc-next-button.ui-button.ui-state-default.ui-corner-right")
      .click()

    // Selecione um horário
    cy.get("#calendar > div.fc-view-container > div > table > tbody > tr > td >\
            div > div > div.fc-slats > table > tbody > tr:nth-child(29)\
            > td:nth-child(2)")
      .click()

    // Modelo do Caminhão
    cy.get('#truckAxle').select('9 EIXO - 74100.0', { force: true })

    // Placa do Cavalo
    cy.get('#licensePlate').clear().type('AAA-4E37')

    // Peso líquido
    cy.get('#netWeight').type('32000,00')

    // Produto
    cy.get('#product').select('MINÉRIO PELLET FEED')

    // Lote
    cy.get('#lot').select('2855', { force: true })

    // Dados do motorista
    // CPF
    cy.get('#driverDocument').type('066.358.569-03')

    // Celular
    cy.get('#driverPhone').type('(42) 998765641')

    // Nome
    cy.get('#driverName').type('Rogerio Cândido')

    // Salvar agendamento
    cy.get('#btnSaveSchedule').click()
  });
});
